"""Tests for TURBO historical OHLCV data validation."""

import pandas as pd
import pytest

from turbo.data import DataValidationError, validate_ohlcv


@pytest.fixture
def valid_data():
    return pd.DataFrame(
        {
            "timestamp": ["2025-01-01T00:00:00Z", "2025-01-01T00:15:00Z"],
            "open": [100, 101],
            "high": [103, 104],
            "low": [99, 100],
            "close": [101, 102],
            "volume": [1200, 1350],
        }
    )


def test_valid_data_is_normalized(valid_data):
    result = validate_ohlcv(valid_data)
    assert list(result.columns) == ["timestamp", "open", "high", "low", "close", "volume"]
    assert len(result) == 2
    assert str(result["timestamp"].dt.tz) == "UTC"
    assert result["close"].tolist() == [101.0, 102.0]


def test_missing_column_is_rejected(valid_data):
    with pytest.raises(DataValidationError, match="Missing required columns"):
        validate_ohlcv(valid_data.drop(columns=["volume"]))


def test_duplicate_timestamps_are_rejected(valid_data):
    valid_data.loc[1, "timestamp"] = valid_data.loc[0, "timestamp"]
    with pytest.raises(DataValidationError, match="unique"):
        validate_ohlcv(valid_data)


def test_unsorted_timestamps_are_rejected(valid_data):
    valid_data.loc[0, "timestamp"], valid_data.loc[1, "timestamp"] = (
        valid_data.loc[1, "timestamp"], valid_data.loc[0, "timestamp"]
    )
    with pytest.raises(DataValidationError, match="ascending"):
        validate_ohlcv(valid_data)


def test_invalid_high_is_rejected(valid_data):
    valid_data.loc[0, "high"] = 98
    with pytest.raises(DataValidationError, match="high"):
        validate_ohlcv(valid_data)


def test_negative_volume_is_rejected(valid_data):
    valid_data.loc[0, "volume"] = -1
    with pytest.raises(DataValidationError, match="Volume cannot be negative"):
        validate_ohlcv(valid_data)


def test_non_numeric_price_is_rejected(valid_data):
    valid_data.loc[0, "close"] = "not-a-price"
    with pytest.raises(DataValidationError, match="numeric"):
        validate_ohlcv(valid_data)
