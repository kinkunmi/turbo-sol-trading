# TURBO — SOL Momentum Intelligence

Stage 1 starter project: project structure, dependencies, historical OHLCV data validation, and automated tests.

This version does **not** fetch market data, generate trading signals, backtest trades, or place orders. Those features belong to later stages.

## Requirements
- Python 3.11 or newer
- pip

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pytest -q
```

On Windows PowerShell, activate the environment with:

```powershell
.venv\Scripts\Activate.ps1
```

## Data format

The validator expects a pandas DataFrame with these columns:

`timestamp, open, high, low, close, volume`

Timestamps must be parseable dates. Rows must be in chronological order and timestamps must be unique. Prices must be positive, OHLC values must be internally consistent, and volume cannot be negative.

The validator returns a cleaned copy with timestamps converted to UTC and numeric OHLCV columns.

## Stage 1 scope
- Create the starter package and folders.
- Validate historical OHLCV data.
- Test valid and invalid datasets.
- No trading or profitability claims.
