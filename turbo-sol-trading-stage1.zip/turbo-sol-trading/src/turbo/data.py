"""Validation helpers for historical OHLCV market data."""

from __future__ import annotations

import pandas as pd

REQUIRED_COLUMNS = ("timestamp", "open", "high", "low", "close", "volume")
PRICE_COLUMNS = ("open", "high", "low", "close")
NUMERIC_COLUMNS = (*PRICE_COLUMNS, "volume")


class DataValidationError(ValueError):
    """Raised when historical OHLCV data fails validation."""


def validate_ohlcv(data: pd.DataFrame) -> pd.DataFrame:
    """Validate OHLCV candles and return a normalized copy.

    Expected columns: timestamp, open, high, low, close, volume.
    Timestamps must be unique and already in ascending chronological order.
    Price values must be positive; volume must be non-negative.
    """
    if not isinstance(data, pd.DataFrame):
        raise DataValidationError("Input must be a pandas DataFrame.")

    missing = [column for column in REQUIRED_COLUMNS if column not in data.columns]
    if missing:
        raise DataValidationError(f"Missing required columns: {', '.join(missing)}")

    result = data.loc[:, REQUIRED_COLUMNS].copy()

    try:
        timestamps = pd.to_datetime(result["timestamp"], utc=True, errors="raise")
    except (ValueError, TypeError) as exc:
        raise DataValidationError("Timestamp values must be valid dates.") from exc

    if timestamps.isna().any():
        raise DataValidationError("Timestamp values cannot be missing.")
    if timestamps.duplicated().any():
        raise DataValidationError("Timestamps must be unique; duplicate candles found.")
    if not timestamps.is_monotonic_increasing:
        raise DataValidationError("Candles must be sorted in ascending timestamp order.")
    result["timestamp"] = timestamps

    for column in NUMERIC_COLUMNS:
        try:
            result[column] = pd.to_numeric(result[column], errors="raise")
        except (ValueError, TypeError) as exc:
            raise DataValidationError(f"Column '{column}' must contain numeric values.") from exc

    if result[list(NUMERIC_COLUMNS)].isna().any().any():
        raise DataValidationError("OHLCV numeric values cannot be missing.")

    # Convert to floats and reject infinities / NaNs.
    result.loc[:, NUMERIC_COLUMNS] = result.loc[:, NUMERIC_COLUMNS].astype(float)
    if not result[list(NUMERIC_COLUMNS)].map(lambda value: pd.notna(value) and abs(value) != float("inf")).all().all():
        raise DataValidationError("OHLCV values must be finite numbers.")

    if (result[list(PRICE_COLUMNS)] <= 0).any().any():
        raise DataValidationError("Open, high, low, and close prices must be positive.")
    if (result["volume"] < 0).any():
        raise DataValidationError("Volume cannot be negative.")

    if (result["high"] < result[["open", "close", "low"]].max(axis=1)).any():
        raise DataValidationError("Each candle's high must be at least its open, close, and low.")
    if (result["low"] > result[["open", "close", "high"]].min(axis=1)).any():
        raise DataValidationError("Each candle's low must be no greater than its open, close, and high.")

    return result.reset_index(drop=True)
